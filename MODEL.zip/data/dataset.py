import os
import cv2
import numpy as np
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from .json_processor import LabelmeJSONParser  # 新增导入
from .image_loader import ImageLoader  # 新增导入


class MRIDataset(Dataset):
    def __init__(self, image_dir, json_dir, transform=None, file_list=None):
        """
        初始化数据集。

        参数:
            image_dir (str): 图像文件目录。
            json_dir (str): JSON 标注文件目录。
            transform (callable, optional): 图像和掩码的变换函数。
            file_list (list, optional): 使用的文件列表。如果为 None，则使用所有文件。
        """
        self.image_dir = image_dir
        self.json_dir = json_dir
        self.transform = transform

        # 如果 file_list 为 None，则加载 image_dir 下的所有文件
        if file_list is None:
            self.file_list = [
                f for f in os.listdir(image_dir)
                if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))
            ]
        else:
            # 如果 file_list 提供了完整路径，提取文件名
            self.file_list = [os.path.basename(f) for f in file_list]


    def __len__(self):
        return len(self.file_list)

    def __getitem__(self, idx):
        # 获取文件名
        image_name = self.file_list[idx]

        # 拼接图像路径
        image_path = os.path.join(self.image_dir, image_name)
        print(f"Loading image: {image_path}")  # 调试输出

        # 加载图像
        try:
            image = ImageLoader.load_image(image_path)
        except Exception as e:
            print(f"Error loading image {image_path}: {e}")
            raise

        # 拼接 JSON 路径
        json_name = os.path.splitext(image_name)[0] + '.json'
        json_path = os.path.join(self.json_dir, json_name)
        print(f"Loading JSON: {json_path}")  # 调试输出

        # 检查 JSON 文件是否存在
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"JSON file not found: {json_path}")

        # 解析 JSON 标注
        parser = LabelmeJSONParser(json_path, image.shape[:2])
        mask = parser.get_mask()

        # 应用变换
        if self.transform:
            image = self.transform(image)
            mask = self.transform(mask)

        return image, mask

def get_transforms(img_size=256):
    return transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5], std=[0.5])
    ])


def get_dataloaders(config):
    # 确保配置文件中包含必要的键
    required_keys = ["image_dir", "json_dir", "img_size", "test_size", "random_state"]
    for key in required_keys:
        if key not in config["data"]:
            raise KeyError(f"Missing required key in config: data.{key}")

    # 从配置文件获取路径
    image_dir = config["data"]["image_dir"]
    json_dir = config["data"]["json_dir"]

    # 获取图像文件列表
    image_files = ImageLoader.get_image_files(image_dir)

    # 划分数据集
    train_files, val_files = train_test_split(
        image_files,
        test_size=config["data"]["test_size"],
        random_state=config["data"]["random_state"]
    )

    # 打印调试信息
    print(f"Image directory: {image_dir}")
    print(f"JSON directory: {json_dir}")
    print(f"Train files: {len(train_files)}")
    print(f"Validation files: {len(val_files)}")

    # 创建数据集实例
    transform = get_transforms(config["data"]["img_size"])
    train_dataset = MRIDataset(image_dir, json_dir, transform, train_files)
    val_dataset = MRIDataset(image_dir, json_dir, transform, val_files)

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=config["training"]["batch_size"],
        shuffle=True
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=config["training"]["batch_size"]
    )

    return train_loader, val_loader