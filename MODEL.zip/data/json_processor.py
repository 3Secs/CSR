import json
import numpy as np
import cv2


class LabelmeJSONParser:
    def __init__(self, json_path, img_size=(512, 512)):
        self.json_path = json_path
        self.img_size = img_size
        self.mask = np.zeros(img_size, dtype=np.uint8)

        with open(json_path) as f:
            self.data = json.load(f)

    def _parse_shapes(self):
        """解析JSON中的多边形标注"""
        for shape in self.data['shapes']:
            if shape['shape_type'] == 'polygon':
                points = np.array(shape['points'], dtype=np.int32)
                cv2.fillPoly(self.mask, [points], color=255)
        return self.mask

    def get_mask(self):
        """获取二值化掩码"""
        return self._parse_shapes()

    @staticmethod
    def show_mask(mask):
        cv2.imshow('Mask Preview', mask)
        cv2.waitKey(0)