import yaml
import torch
from torch import optim
from data.dataset import get_dataloaders
from models.unet import UNet
from models.losses import DiceLoss
from utils.metrics import calculate_dice


def train(config_path):
    # 加载配置
    with open(config_path) as f:
        config = yaml.safe_load(f)

    # 初始化模型
    model = UNet(
        in_channels=config["model"]["in_channels"],
        out_channels=config["model"]["out_channels"],
        init_features=config["model"]["init_features"]
    ).to(config["training"]["device"])

    # 损失函数和优化器
    criterion = DiceLoss()
    optimizer = optim.Adam(
        model.parameters(),
        lr=config["training"]["learning_rate"]
    )

    # 数据加载
    train_loader, val_loader = get_dataloaders(config)

    # 训练循环
    for epoch in range(config["training"]["num_epochs"]):
        model.train()
        train_loss = 0.0
        for images, masks in train_loader:
            images = images.to(config["training"]["device"])
            masks = masks.to(config["training"]["device"])

            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, masks)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        # 验证
        val_loss, val_dice = 0.0, 0.0
        model.eval()
        with torch.no_grad():
            for images, masks in val_loader:
                images = images.to(config["training"]["device"])
                masks = masks.to(config["training"]["device"])
                outputs = model(images)
                val_loss += criterion(outputs, masks).item()
                val_dice += calculate_dice(outputs, masks)

        print(f"Epoch {epoch + 1}/{config['training']['num_epochs']}")
        print(f"Train Loss: {train_loss / len(train_loader):.4f}")
        print(f"Val Loss: {val_loss / len(val_loader):.4f}")
        print(f"Val Dice: {val_dice / len(val_loader):.4f}\n")


if __name__ == "__main__":
    train("configs/base_config.yaml")